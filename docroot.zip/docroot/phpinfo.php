<?php>
phpinfo();
?>
